package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.common.enums.SortDirection;
import net.jacobpeterson.alpaca.model.endpoint.orders.CancelledOrder;
import net.jacobpeterson.alpaca.model.endpoint.orders.Order;
import net.jacobpeterson.alpaca.model.endpoint.orders.enums.CurrentOrderStatus;
import net.jacobpeterson.alpaca.model.endpoint.orders.enums.OrderSide;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;

import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;

public class Orders {
    public static List<Order> getAllOrders(AlpacaAPI api) {
        try {
            List<Order> orders;
            orders = api.orders().get(
                    CurrentOrderStatus.ALL,
                    null,
                    null,
                    null,
                    SortDirection.ASCENDING,
                    true,
                    null);
            return orders;
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static List<Order> getAllOrders(AlpacaAPI api,ZonedDateTime after,ZonedDateTime until) {
        try {
            List<Order> orders;
            orders = api.orders().get(
                    CurrentOrderStatus.ALL,
                    null,
                    after,
                    until,
                    SortDirection.ASCENDING,
                    true,
                    null);
            return orders;
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void getOrdersByStockName(AlpacaAPI api,String stockName) {

        try {
            List<Order> orders = api.orders().get(
                    CurrentOrderStatus.ALL,
                    null,
                    null,
                    null,
                    SortDirection.ASCENDING,
                    true,
                    Collections.singletonList(stockName));
            orders.forEach(System.out::println);
        } catch (AlpacaClientException e) {
            System.out.printf("Server did not return [%s] shares\n",stockName);
        }
    }

    public static void getOrdersByStockName(AlpacaAPI api,String stockName,ZonedDateTime after,ZonedDateTime until) {

        try {
            List<Order> orders = api.orders().get(
                    CurrentOrderStatus.ALL,
                    null,
                    after,
                    until,
                    SortDirection.ASCENDING,
                    true,
                    Collections.singletonList(stockName));
            orders.forEach(System.out::println);
        } catch (AlpacaClientException e) {
            System.out.printf("Server did not return [%s] shares\n",stockName);
        }
    }

    public static void printAllOrders(AlpacaAPI api) {
        List<Order> orders = getAllOrders(api);
        if (orders == null) {
            System.out.println("No new orders");
            return;
        }
        System.out.println("Your orders:");
        for (Order o : orders) {
            String id = o.getId();
            String submitDate = o.getSubmittedAt().toString();
            String stockName = o.getSymbol();
            String quantity = o.getQuantity();
            String action = o.getSide().toString();
            System.out.printf("\t%s [%s] q:%s\t%s\t(%s)\n",action,stockName,quantity,submitDate,id);
        }
    }

    public static void printAllOrders(AlpacaAPI api,ZonedDateTime after,ZonedDateTime until) {
        List<Order> orders = getAllOrders(api,after,until);
        if (orders == null) {
            System.out.println("No new orders");
            return;
        }
        System.out.println("Your orders:");
        for (Order o : orders) {
            String id = o.getId();
            String submitDate = o.getSubmittedAt().toString();
            String stockName = o.getSymbol();
            String quantity = o.getQuantity();
            String action = o.getSide().toString();
            System.out.printf("\t%s [%s] q:%s\t%s\t(%s)\n",action,stockName,quantity,submitDate,id);
        }
    }

    public static void buyShareByQuantity(AlpacaAPI api,String stockName,Double quantity) {
        try {
            api.orders().requestFractionalMarketOrder(stockName, quantity, OrderSide.BUY);
            System.out.printf("[+] Bought %f shares of [%s]\n",quantity,stockName);
        } catch (AlpacaClientException e) {
            System.out.printf("Could not buy [%s]\n",stockName);
        }
    }

    public static void buyShareByPrice(AlpacaAPI api,String stockName,Double price) {
        try {
            api.orders().requestNotionalMarketOrder(stockName,price,OrderSide.BUY);
            System.out.printf("[+] Bought %f$ worth of shares of [%s]\n",price,stockName);
        } catch (AlpacaClientException e) {
            System.out.printf("Could not buy [%s]\n",stockName);
        }
    }

    public static void sellShareByQuantity(AlpacaAPI api,String stockName,Double quantity) {
        try {
            api.orders().requestFractionalMarketOrder(stockName, quantity, OrderSide.SELL);
            System.out.printf("[-] Sold %f shares of [%s]\n",quantity,stockName);
        } catch (AlpacaClientException e) {
            System.out.printf("Could not sell [%s]\n",stockName);
        }
    }

    public static void sellShareByPrice(AlpacaAPI api,String stockName,Double price) {
        try {
            api.orders().requestNotionalMarketOrder(stockName,price,OrderSide.SELL);
            System.out.printf("[-] Sold %f$ worth of shares of [%s]\n",price,stockName);
        } catch (AlpacaClientException e) {
            System.out.printf("Could not sell [%s]\n",stockName);
        }
    }

    public static void cancelAllOrders(AlpacaAPI api) {
        try {
            List<CancelledOrder> cancelledOrders = api.orders().cancelAll();
            cancelledOrders.forEach((cancelledOrder) -> System.out.printf("Cancelled: %s\n", cancelledOrder));
        } catch (AlpacaClientException e) {
            System.out.println("There was an error cancelling orders");
        }
    }
}
