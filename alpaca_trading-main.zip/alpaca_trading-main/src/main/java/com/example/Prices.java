package com.example;

public class Prices {
    public Double openPrice;
    public Double closePrice;
}
