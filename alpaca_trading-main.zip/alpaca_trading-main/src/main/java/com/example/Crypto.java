package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.assets.Asset;
import net.jacobpeterson.alpaca.model.endpoint.assets.enums.AssetClass;
import net.jacobpeterson.alpaca.model.endpoint.assets.enums.AssetStatus;
import net.jacobpeterson.alpaca.model.endpoint.marketdata.crypto.historical.bar.CryptoBar;
import net.jacobpeterson.alpaca.model.endpoint.marketdata.crypto.historical.snapshot.CryptoSnapshot;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;

import java.util.*;

public class Crypto {
    public static List<String> getTradable(AlpacaAPI api) {
        try {
            List<Asset> activeUSEquities = api.assets().get(AssetStatus.ACTIVE, AssetClass.CRYPTO);
            List<String> assetNames = new ArrayList<>();
            for (Asset a : activeUSEquities) {
                assetNames.add(a.getSymbol());
            }
            return assetNames;
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Boolean isValidName(AlpacaAPI api,String stockName) {
        List<String> activeAssets = getTradable(api);
        if (activeAssets == null) {
            System.out.println("[!] Error getting active assets");
            return false;
        }
        return activeAssets.contains(stockName);
    }

    private static String getAssetId(AlpacaAPI api,String stockName) {
        try {
            Asset a = api.assets().getBySymbol(stockName);
            return a.getId();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Asset getAssetByName(AlpacaAPI api,String stockName) {
        String assetId = getAssetId(api,stockName);
        try {
            return api.assets().getBySymbol(assetId);
        } catch (AlpacaClientException e) {
            System.out.println("[!] Error getting assetId for " + stockName);
            return null;
        }
    }

    public static CryptoBar getLastDailyBar(AlpacaAPI api, String assetName) {
        try {
            Map<String, CryptoSnapshot> snapshots = api.cryptoMarketData()
                    .getSnapshots(Collections.singletonList(assetName)).getSnapshots();
            Map.Entry<String, CryptoSnapshot> firstEntry = snapshots.entrySet().iterator().next();
            CryptoSnapshot firstSnapshot = firstEntry.getValue();
            return firstSnapshot.getDailyBar();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static CryptoBar getLastMinuteBar(AlpacaAPI api, String assetName) {
        try {
            Map<String, CryptoSnapshot> snapshots = api.cryptoMarketData()
                    .getSnapshots(Collections.singletonList(assetName)).getSnapshots();
            Map.Entry<String, CryptoSnapshot> firstEntry = snapshots.entrySet().iterator().next();
            CryptoSnapshot firstSnapshot = firstEntry.getValue();
            return firstSnapshot.getMinuteBar();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

        public static Prices getLastDayPrices(AlpacaAPI api, String assetName) {
        CryptoBar cryptoBar = getLastDailyBar(api,assetName);
        if (cryptoBar == null) {
            System.out.println("[!] Error getting last stockbar");
            return null;
        }
        Prices p = new Prices();
        p.openPrice = cryptoBar.getHigh();
        p.closePrice = cryptoBar.getLow();
        return p;
    }

    public static Prices getLastMinutePrices(AlpacaAPI api, String assetName) {
        CryptoBar cryptoBar = getLastMinuteBar(api,assetName);
        if (cryptoBar == null) {
            System.out.println("[!] Error getting last stockbar");
            return null;
        }
        Prices p = new Prices();
        p.openPrice = cryptoBar.getHigh();
        p.closePrice = cryptoBar.getLow();
        return p;
    }

    public Double getLastDayAverage(AlpacaAPI api,String stockName) {
        Prices p = getLastDayPrices(api,stockName);
        if (p == null) {
            System.out.println("[!] Stock prices null");
            return null;
        }
//        System.out.println("[+] Calculating new avg: " + (p.openPrice+p.closePrice)/2.0);
        return (p.openPrice+p.closePrice)/2.0;
    }

    public static Double getLastMinuteAverage(AlpacaAPI api, String stockName) {
        Prices p = getLastMinutePrices(api,stockName);
        if (p == null) {
            System.out.println("[!] Stock prices null");
            return null;
        }
//        System.out.println("[+] Calculating new avg: " + (p.openPrice+p.closePrice)/2.0);
        return (p.openPrice+p.closePrice)/2.0;
    }

    public static void printTradable(AlpacaAPI api) {
        List<String> tradableAssets = getTradable(api);
        if (tradableAssets == null) {
            System.out.println("No tradable assets found");
            return;
        }
        System.out.println(String.join(", ",tradableAssets));
    }
}
