package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.assets.Asset;
import net.jacobpeterson.alpaca.model.endpoint.assets.enums.AssetClass;
import net.jacobpeterson.alpaca.model.endpoint.assets.enums.AssetStatus;
import net.jacobpeterson.alpaca.model.endpoint.marketdata.stock.historical.snapshot.Snapshot;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;
import net.jacobpeterson.alpaca.model.endpoint.marketdata.stock.historical.bar.StockBar;

import java.util.*;

public class Stocks {
    public static List<String> getTradable(AlpacaAPI api) {
        try {
            List<Asset> activeUSEquities = api.assets().get(AssetStatus.ACTIVE, AssetClass.US_EQUITY);
            List<String> assetNames = new ArrayList<>();
            for (Asset a : activeUSEquities) {
                assetNames.add(a.getSymbol());
            }
            return assetNames;
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Boolean isValidName(AlpacaAPI api,String stockName) {
        List<String> activeAssets = getTradable(api);
        if (activeAssets == null) {
            System.out.println("[!] Error getting active assets");
            return false;
        }
        return activeAssets.contains(stockName);
    }

    public static StockBar getLastDailyBar(AlpacaAPI api, String stockName) {
        try {
            Map<String, Snapshot> snapshots = api.stockMarketData()
                    .getSnapshots(Collections.singletonList(stockName));
            Map.Entry<String, Snapshot> firstEntry = snapshots.entrySet().iterator().next();
            Snapshot firstSnapshot = firstEntry.getValue();
            return firstSnapshot.getDailyBar();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static StockBar getLastMinuteBar(AlpacaAPI api, String stockName) {
        try {
            Map<String, Snapshot> snapshots = api.stockMarketData()
                    .getSnapshots(Collections.singletonList(stockName));
            Map.Entry<String, Snapshot> firstEntry = snapshots.entrySet().iterator().next();
            Snapshot firstSnapshot = firstEntry.getValue();
            return firstSnapshot.getMinuteBar();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

        public static Prices getLastDayPrices(AlpacaAPI api, String assetName) {
        StockBar stockBar = getLastDailyBar(api,assetName);
        if (stockBar == null) {
            System.out.println("[!] Error getting last stockbar");
            return null;
        }
        Prices p = new Prices();
        p.openPrice = stockBar.getHigh();
        p.closePrice = stockBar.getLow();
        return p;
    }

    public static Prices getLastMinutePrices(AlpacaAPI api, String assetName) {
        StockBar stockBar = getLastMinuteBar(api,assetName);
        if (stockBar == null) {
            System.out.println("[!] Error getting last stockbar");
            return null;
        }
        Prices p = new Prices();
        p.openPrice = stockBar.getHigh();
        p.closePrice = stockBar.getLow();
        return p;
    }

    public Double getLastDayAverage(AlpacaAPI api,String stockName) {
        Prices p = getLastDayPrices(api,stockName);
        if (p == null) {
            System.out.println("[!] Stock prices null");
            return null;
        }
//        System.out.println("[+] Calculating new avg: " + (p.openPrice+p.closePrice)/2.0);
        return (p.openPrice+p.closePrice)/2.0;
    }

    public static Double getLastMinuteAverage(AlpacaAPI api, String stockName) {
        Prices p = getLastMinutePrices(api,stockName);
        if (p == null) {
            System.out.println("[!] Stock prices null");
            return null;
        }
//        System.out.println("[+] Calculating new avg: " + (p.openPrice+p.closePrice)/2.0);
        return (p.openPrice+p.closePrice)/2.0;
    }

    public static void printStockData(AlpacaAPI alpacaAPI,String stockName) {
        StockBar minuteBar = getLastMinuteBar(alpacaAPI,stockName);
        if (minuteBar == null) {
            System.out.println("[!] Error getting last minute bar");
            return;
        }
        Double openPrice = minuteBar.getOpen();
        Double highPrice = minuteBar.getHigh();
        Double lowPrice = minuteBar.getLow();
        Double closePrice = minuteBar.getHigh();
        Long volume = minuteBar.getVolume();
        System.out.printf("%s: \t[open] %f [close] %f \n\t\t[low] %f [high] %f \n\t\t[volume] %d",stockName,openPrice,closePrice,lowPrice,highPrice,volume);
    }

    public static void printStockPrice(AlpacaAPI api,String stockName) {
        Prices p = Stocks.getLastMinutePrices(api,stockName);
        if (p == null) {
            System.out.println("[!] Error getting prices");
            return;
        }
        System.out.printf("[%s]\tOPEN: %f$\tCLOSE: %f$\n",stockName,p.openPrice,p.closePrice);
    }
}
