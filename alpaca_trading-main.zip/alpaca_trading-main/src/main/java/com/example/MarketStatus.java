package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.clock.Clock;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class MarketStatus {
    public static Clock getClock(AlpacaAPI api) {
        try {
            return api.clock().get();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Boolean isOpen(AlpacaAPI api) {
        Clock c = getClock(api);
        if (c == null) {
            System.out.println("[!] There was an error - assuming market is closed");
            return false;
        }
        return c.getIsOpen();
    }

    public static ZonedDateTime getSyncronizedTime(AlpacaAPI api) {
        Clock c = getClock(api);
        if (c == null) {
            System.out.println("[!] There was an error - assuming market is closed");
            return null;
        }
        return c.getTimestamp();
    }

    public static void printFormattedDate(ZonedDateTime zdt) {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss (z)", Locale.UK);
        String time = zdt.format(timeFormatter);

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("EEEE, yyyy-MM-dd", Locale.UK);
        String formattedDate = zdt.format(dateFormatter);
        System.out.printf("Market time: %s\t%s\n",time,formattedDate);
    }
}
