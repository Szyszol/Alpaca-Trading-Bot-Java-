package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.account.Account;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;

import java.time.ZoneId;
import java.time.ZonedDateTime;


public class Main {
    public static void sleep(int seconds) {
        try {
            Thread.sleep(seconds*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static Account connectAccount(AlpacaAPI alpacaAPI) {
        try {
            // Get account info
            return alpacaAPI.account().get();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ZonedDateTime synchronizeClocks(AlpacaAPI api) {
        ZonedDateTime clock = MarketStatus.getSyncronizedTime(api);
        if (clock != null) {
            return clock;
        }
        System.out.println("[*] Error getting remote clock - setting to local");
        ZoneId zoneId = ZoneId.of("Europe/Warsaw");
        return ZonedDateTime.now(zoneId);
    }

    public static void main(String[] args) {
        AlpacaAPI api = new AlpacaAPI();

        Account account = connectAccount(api);
        if (account == null) {
            System.out.println("[!] Unable to get account data - check config or network connectivity");
            sleep(1);
            System.exit(1);
        }

        String accountNumber = account.getAccountNumber();
        System.out.printf("Hello %s!\n",accountNumber);

        ZonedDateTime clock = synchronizeClocks(api);
        MarketStatus.printFormattedDate(clock);

        Bot bot = new Bot(api,account);
        ConsoleGUI console = new ConsoleGUI(api,bot);
        console.start();
    }
}