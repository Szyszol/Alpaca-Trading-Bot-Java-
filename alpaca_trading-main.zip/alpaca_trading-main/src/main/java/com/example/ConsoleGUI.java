package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.account.Account;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;

import java.util.List;
import java.util.Scanner;

public class ConsoleGUI {

    private final AlpacaAPI api;
    private final Bot bot;

    public ConsoleGUI(AlpacaAPI api,Bot bot) {
        this.api = api;
        this.bot = bot;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            printMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    viewOpenPositions();
                    break;
                case 2:
                    listTradableAssets();
                    break;
                case 3:
                    subscribeStock(scanner);
                    break;
                case 4:
                    unsubscribeStock(scanner);
                    break;
                case 5:
                    subscribeCrypto(scanner);
                    break;
                case 6:
                    unsubscribeCrypto(scanner);
                    break;
                case 7:
                    showAvailableFunds();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void printMenu() {
        System.out.println();
        System.out.println(" ---- EliteTradeEngine3000 ---- ");
        System.out.println("1. View Open Positions");
        System.out.println("2. List Tradable Assets");
        System.out.println("3. Subscribe to Stock");
        System.out.println("4. Unsubscribe from Stock");
        System.out.println("5. Subscribe to Crypto");
        System.out.println("6. Unsubscribe from Crypto");
        System.out.println("7. Show available funds");
        System.out.println("8. Exit");
        System.out.print("Enter your choice: ");
    }

    private void viewOpenPositions() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Filter by asset name (leave empty for all): ");
        String assetName = scanner.nextLine();
        if (!assetName.isEmpty()) Positions.printOpenPositions(this.api,assetName);
        else Positions.printOpenPositions(this.api);
    }

    private void listTradableAssets() {
        List<String> tradableStocks = Stocks.getTradable(this.api);
        System.out.println("Tradable Stocks:");
        if (tradableStocks == null) System.out.println("\tnone");
        else System.out.println(String.join(", ",tradableStocks));

        List<String> tradableCryptos = Crypto.getTradable(this.api);
        System.out.println("\nTradable Cryptos:");
        if (tradableCryptos == null) System.out.println("\tnone");
        else System.out.println(String.join(", ",tradableCryptos));
    }

    private void subscribeStock(Scanner scanner) {
        System.out.print("Enter assetName to subscribe: ");
        String assetName = scanner.nextLine();
        if (assetName.isEmpty()) {
            System.out.println("Asset name cannot be empty");
            return;
        }
        bot.subscribeStock(assetName);
    }

    private void unsubscribeStock(Scanner scanner) {
        System.out.print("Enter assetName to unsubscribe: ");
        String assetName = scanner.nextLine();
        if (assetName.isEmpty()) {
            System.out.println("Asset name cannot be empty");
            return;
        }
        bot.unsubscribeStock(assetName);
    }

    private void subscribeCrypto(Scanner scanner) {
        System.out.print("Enter assetName to subscribe: ");
        String assetName = scanner.nextLine();
        if (assetName.isEmpty()) {
            System.out.println("Asset name cannot be empty");
            return;
        }
        bot.subscribeCrypto(assetName);
    }

    private void unsubscribeCrypto(Scanner scanner) {
        System.out.print("Enter assetName to unsubscribe: ");
        String assetName = scanner.nextLine();
        if (assetName.isEmpty()) {
            System.out.println("Asset name cannot be empty");
            return;
        }
        bot.unsubscribeCrypto(assetName);
    }

    private void showAvailableFunds() {
        try {
            Account account = this.api.account().get();
            String freeFunds = account.getCash();
            String currency = account.getCurrency();
            System.out.println();
            System.out.println("Free funds: " + freeFunds + " " + currency);
        } catch (AlpacaClientException e) {
            System.out.println("Cannot get available funds");
        }
    }
}