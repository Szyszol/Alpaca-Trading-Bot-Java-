package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.account.Account;

import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class Bot {
    private final AlpacaAPI api;
    private final Account account;
    private final List<String> subscribedStocks;
    private final List<String> subscribedCrypto;
    private final Map<String, LinkedList<Double>> SMA;

    private final int maxSmaLength;


    public Bot(AlpacaAPI api, Account account){
        this.api = api;
        this.account = account;
        this.subscribedStocks = new ArrayList<>();
        this.subscribedCrypto = new ArrayList<>();
        this.SMA = new HashMap<>();
        this.maxSmaLength = 20;

        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::runBot, 0, 15, TimeUnit.SECONDS);
    }

    public void runBot() {
//        System.out.println("[*] Running next iteration");
        for (String stockName : this.subscribedStocks) {
            Double avg = Stocks.getLastMinuteAverage(this.api,stockName);
//            System.out.println("[*] Updating averages");
            updateAverages(stockName,avg);
        }
        for (String cryptoName : this.subscribedCrypto) {
            Double avg = Crypto.getLastMinuteAverage(this.api,cryptoName);
//            System.out.println("[*] Updating averages");
            updateAverages(cryptoName,avg);
        }
        executeStrategy();

    }

    public void updateAverages(String assetName, double value) {
        if (!this.SMA.containsKey(assetName)) {
            this.SMA.put(assetName, new LinkedList<>());
        }
        this.SMA.get(assetName).addLast(value);
        if (this.SMA.get(assetName).size() > this.maxSmaLength) {
            this.SMA.get(assetName).removeFirst();
        }
    }

    public void subscribeStock(String stockName) {
        if (!Stocks.isValidName(this.api,stockName)) {
            System.out.println("[!] Invalid stock name");
            return;
        }
        if (!this.subscribedStocks.contains(stockName)) {
            this.subscribedStocks.add(stockName);
            System.out.println("[*] Subscribed to " + stockName);
        }
    }

    public void unsubscribeStock(String stockName) {
        if (!Stocks.isValidName(this.api,stockName)) {
            System.out.println("[!] Invalid stock name");
            return;
        }
        if (!this.subscribedStocks.contains(stockName)) {
            return;
        }
        this.subscribedStocks.remove(stockName);
        System.out.println("[*] Unsubscribed from " + stockName);
    }

    public void subscribeCrypto(String assetName) {
        if (!Crypto.isValidName(this.api,assetName)) {
            System.out.println("[!] Invalid stock name");
            return;
        }
        if (!this.subscribedCrypto.contains(assetName)) {
            this.subscribedCrypto.add(assetName);
            System.out.println("[*] Subscribed to " + assetName);
        }
    }

    public void unsubscribeCrypto(String assetName) {
        if (!Crypto.isValidName(this.api,assetName)) {
            System.out.println("[!] Invalid stock name");
            return;
        }
        if (!this.subscribedCrypto.contains(assetName)) {
            return;
        }
        this.subscribedCrypto.remove(assetName);
        System.out.println("[*] Unsubscribed from " + assetName);
    }

    private void printSMAStatus() {
        for (Map.Entry<String, LinkedList<Double>> entry : this.SMA.entrySet()) {
            String assetName = entry.getKey();
            LinkedList<Double> values = entry.getValue();

            System.out.printf("[%s]\t",assetName);
            System.out.println(values);
        }
        System.out.println();
    }

    private Map<String, Double> calculateSMAs() {
        Map<String, Double> calculatedSMAs = new HashMap<>();
        for (Map.Entry<String, LinkedList<Double>> entry : this.SMA.entrySet()) {
            Double sma = 0.0;
            String assetName = entry.getKey();
            LinkedList<Double> values = entry.getValue();

            double stockSum = 0.0;
            int n = values.size();
            for (Double value : values) {
                stockSum += value;
            }
            sma = stockSum/n;
//            System.out.printf("[%s]\tSMA: %f\n",assetName,sma);
            calculatedSMAs.put(assetName,sma);
        }
        return calculatedSMAs;
    }

    private void executeStrategy() {
        if (!MarketStatus.isOpen(this.api)) {
            System.out.println("[/] Market is closed");
            return;
        }
        Map<String, Double> calculatedSMAs = calculateSMAs();
        for (String stockName : this.subscribedStocks) {
            Double currentStockValue = Stocks.getLastMinuteAverage(this.api,stockName);
            if (currentStockValue == null) continue;
            if (currentStockValue < calculatedSMAs.get(stockName)) {
                if (Double.parseDouble(account.getCash()) >= currentStockValue) Orders.buyShareByQuantity(this.api,stockName,1.0);
            } else {
                Double qty = Positions.calulateQtyOf(this.api,stockName);
                if (qty > 0) {
                    Orders.sellShareByQuantity(this.api,stockName,qty);
                }
            }
        }
        for (String cryptoName : this.subscribedCrypto) {
            Double currentCryptoValue = Crypto.getLastMinuteAverage(this.api,cryptoName);
            if (currentCryptoValue == null) continue;
            if (currentCryptoValue < calculatedSMAs.get(cryptoName)) {
                if (Double.parseDouble(account.getCash()) >= currentCryptoValue) Orders.buyShareByQuantity(this.api,cryptoName,1.0);
            } else {
                Double qty = Positions.calulateQtyOf(this.api,cryptoName);
                if (qty > 0){
                    Orders.sellShareByQuantity(this.api,cryptoName,qty);
                }
            }
        }
    }
}
