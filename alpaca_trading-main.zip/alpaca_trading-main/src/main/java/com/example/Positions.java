package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.positions.Position;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;

import java.util.ArrayList;
import java.util.List;

public class Positions {
    public static List<Position> getOpenPositions(AlpacaAPI api) {
        try {
            return api.positions().get();
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<Position> getOpenPositions(AlpacaAPI api,String stockName) {
        try {
            List<Position> openPositions = api.positions().get();
            List<Position> stockNamePositions = new ArrayList<>();
            for (Position openPosition : openPositions) {
                if (openPosition.getSymbol().equals(stockName)) {
                    stockNamePositions.add(openPosition);
                }
            }
            return stockNamePositions;
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void printOpenPositions(AlpacaAPI api) {
        List<Position> openPositions = getOpenPositions(api);
        if (openPositions == null) {
            System.out.println("No open positions found");
            return;
        }
        System.out.println("Your open positions:");
        for (Position openPosition : openPositions) {
            String symbol = openPosition.getSymbol();
            String quantity = openPosition.getQuantity();
            String value = openPosition.getMarketValue();
            System.out.printf("\t[%s] q: %s\tvalue: %s\n",symbol,quantity,value);
        }
    }

    public static void printOpenPositions(AlpacaAPI api,String assetName) {
        assetName = assetName.toUpperCase();
        List<Position> openPositions = getOpenPositions(api,assetName);
        if (openPositions == null) {
            System.out.println("No open positions found");
            return;
        }
        System.out.println("Your open positions:");
        for (Position openPosition : openPositions) {
            String symbol = openPosition.getSymbol();
            String quantity = openPosition.getQuantity();
            String value = openPosition.getMarketValue();
            System.out.printf("\t[%s] q: %s\tvalue: %s\n",symbol,quantity,value);
        }
    }

    public static Double calulateQtyOf(AlpacaAPI api,String stockName) {
        double qty = 0.0;
        List<Position> openPositions = getOpenPositions(api,stockName);
        if (openPositions == null) {
            return qty;
        }
        for (Position openPosition : openPositions) {
            qty += Double.parseDouble(openPosition.getQuantity());
        }
        return qty;
    }

    public static Double calulateValueOf(AlpacaAPI api,String stockName) {
        double totalValue = 0.0;
        List<Position> openPositions = getOpenPositions(api,stockName);
        if (openPositions == null) {
            return totalValue;
        }
        for (Position openPosition : openPositions) {
            double qty = Double.parseDouble(openPosition.getQuantity());
            double value = Double.parseDouble(openPosition.getMarketValue());
            totalValue += qty*value;
        }
        return totalValue;
    }
}
