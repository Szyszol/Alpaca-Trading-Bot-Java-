package com.example;

import net.jacobpeterson.alpaca.AlpacaAPI;
import net.jacobpeterson.alpaca.model.endpoint.assets.Asset;
import net.jacobpeterson.alpaca.model.endpoint.assets.enums.AssetClass;
import net.jacobpeterson.alpaca.model.endpoint.assets.enums.AssetStatus;
import net.jacobpeterson.alpaca.rest.AlpacaClientException;

import java.util.ArrayList;
import java.util.List;

public class Assets {
    public static List<String> getTradableAssets(AlpacaAPI api) {
        try {
            List<Asset> activeAssets = api.assets().get(AssetStatus.ACTIVE, null);
            List<String> assetNames = new ArrayList<>();
            for (Asset a : activeAssets) {
                assetNames.add(a.getSymbol());
            }
            return assetNames;
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<String> getTradableAssets(AlpacaAPI api,AssetClass assetClass) {
        try {
            List<Asset> activeAssets = api.assets().get(AssetStatus.ACTIVE, assetClass);
            List<String> assetNames = new ArrayList<>();
            for (Asset a : activeAssets) {
                assetNames.add(a.getSymbol());
            }
            return assetNames;
        } catch (AlpacaClientException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static Boolean isValidAssetName(AlpacaAPI api,String stockName) {
        List<String> activeAssets = getTradableAssets(api);
        if (activeAssets == null) {
            System.out.println("[!] Error getting active assets");
            return false;
        }
        return activeAssets.contains(stockName);
    }
}
